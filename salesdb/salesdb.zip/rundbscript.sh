




echo $PATH
OSNAME=`uname -s`
FILE_PATH=/tmp/applifire/db/AQI9TWFJBCZH4VO1AW5CW/18D01ABF-F632-496A-B379-FC50EDEAB8C0





sh $FILE_PATH/create.sh  
sh $FILE_PATH/alter.sh  
sh $FILE_PATH/loaddata.sh   
