
CREATE USER 'sales'@'%' IDENTIFIED BY 'sales';
